"""Native runtime public boundary."""
